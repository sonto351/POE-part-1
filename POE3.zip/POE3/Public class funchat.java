package POE3;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

class funchat {
    private static int messageCount = 0;

    public static void startChat(String sender) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("welcome to funchart");
            System.out.println("select option");
            System.out.println("1; select chat options");
            System.out.println("2;send message");
            System.out.println("3 quit");
            System.out.println(" enter your choice");

            if (!scanner.hasNextInt()) {
                System.out.println("invalid choice choose 1,2,3");
                scanner.nextLine();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 2:
                    System.out.println("you have selected send message");
                    String receiver;
                    do {
                        System.out.println("enter receiver number(must start with +27 and have exactly 12 numbers)");
                        receiver = scanner.nextLine();
                    } while (!receiver.matches("\\+27\\d{9}"));

                    System.out.println("enter your message it must be 250 characters or less");
                    String message = scanner.nextLine();
                    if (message.length() > 250) {
                        System.out.println("ensure that your message is 250 charecters of less");
                        return;
                    }

                    String messageId = generateMessageId();
                    int currentMessageCount = ++messageCount;
                    String messageHash = generateMessageHash(messageId, currentMessageCount, message);
                    System.out.println("messagehash" + messageHash);
                    System.out.println("choose option");
                    System.out.println("1.Send message");
                    System.out.println("2.Delete message");
                    System.out.println("3.Store message");

                    if (!scanner.hasNextInt()) {
                        System.out.println("invalid option");
                        scanner.nextLine();
                        continue;
                    }

                    int subChoice = scanner.nextInt();
                    scanner.nextLine();

                    switch (subChoice) {
                        case 1:
                            System.out.println("messagesent");
                            manager.addMessage(sender, messageId, receiver, message, messageHash);
                            break;
                        case 2:
                            System.out.println("message deleted");
                            break;
                        case 3:
                            storeMessage(messageId, receiver, message, messageHash);
                            manager.addMessage(sender, messageId, receiver, message, messageHash);
                            break;
                        default:
                            System.out.println("invalid option");
                    }
                    break;
                case 3:
                    System.out.println("quitting");
                    return;
                default:
                    System.out.println("invalid choice choose 1,2,3");
            }
        }
    }

    public static void startchart(String sender) {
        startChat(sender);
    }

    private static String generateMessageId() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    private static String generateMessageHash(String messageId, int count, String message) {
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return messageId.substring(0, 2) + ":" + count + ":" + first.toLowerCase() + last.toLowerCase();
    }

    private static void storeMessage(String id, String receiver, String message, String hash) {
        try (FileWriter fileWriter = new FileWriter("stored message.txt", true)) {
            fileWriter.write("messageid:" + id + System.lineSeparator());
            fileWriter.write("receiver:" + receiver + System.lineSeparator());
            fileWriter.write("message:" + message + System.lineSeparator());
            fileWriter.write("hash:" + hash + System.lineSeparator());
            fileWriter.write("-----" + System.lineSeparator());
            System.out.println("the message has been stored successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
