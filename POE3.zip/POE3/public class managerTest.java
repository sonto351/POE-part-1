package POE3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class managerTest {

    private ByteArrayOutputStream output;

    @BeforeEach
    public void setUp() {
        output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
    }

    @Test
    public void testAddMessage() {
        manager.addMessage(
                "TestSender",
                "1234567890",
                "+27821234567",
                "Hello there",
                "12:1:HELLOTHERE"
        );

        manager.displayFullReport();

        assertTrue(output.toString().contains("TestSender"));
        assertTrue(output.toString().contains("Hello there"));
    }

    @Test
    public void testDisplaySendersAndRecipients() {
        manager.addMessage(
                "SenderOne",
                "1111111111",
                "+27821234567",
                "Testing message",
                "11:1:TESTINGMESSAGE"
        );

        manager.displaySendersAndRecipients();

        assertTrue(output.toString().contains("Senders and Recipients:"));
        assertTrue(output.toString().contains("SenderOne"));
    }

    @Test
    public void testDisplayLongestMessage() {
        manager.addMessage(
                "SenderTwo",
                "2222222222",
                "+27821234567",
                "This is a longer message",
                "22:2:THISMESSAGE"
        );

        manager.displayLongestMessage();

        assertTrue(output.toString().contains("Longest Message:"));
    }

    @Test
    public void testSearchByMessageId() {
        manager.addMessage(
                "SenderThree",
                "3333333333",
                "+27821234567",
                "Find this message",
                "33:3:FINDMESSAGE"
        );

        manager.searchByMessageId("3333333333");

        assertTrue(output.toString().contains("Find this message"));
    }

    @Test
    public void testSearchMessagesByRecipient() {
        manager.addMessage(
                "SenderFour",
                "4444444444",
                "+27821234567",
                "Recipient test",
                "44:4:RECIPIENTTEST"
        );

        manager.searchMessagesByRecipient("+27821234567");

        assertTrue(output.toString().contains("Recipient test"));
    }

    @Test
    public void testDeleteMessageByHash() {
        manager.addMessage(
                "SenderFive",
                "5555555555",
                "+27821234567",
                "Delete this message",
                "55:5:DELETEMESSAGE"
        );

        manager.deleteMessageByHash("55:5:DELETEMESSAGE");

        output.reset();

        manager.searchByMessageId("5555555555");

        assertTrue(output.toString().contains("Message ID not found."));
    }

    @Test
    public void testDisplayFullReport() {
        manager.addMessage(
                "SenderSix",
                "6666666666",
                "+27821234567",
                "Report test",
                "66:6:REPORTTEST"
        );

        manager.displayFullReport();

        assertTrue(output.toString().contains("Full Message Report:"));
        assertTrue(output.toString().contains("Report test"));
    }
}
